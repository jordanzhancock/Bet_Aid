package com.group6.gbac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GbacApplication {

	public static void main(String[] args) {
		SpringApplication.run(GbacApplication.class, args);
	}

}
