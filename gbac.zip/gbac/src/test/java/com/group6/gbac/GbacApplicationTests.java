package com.group6.gbac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GbacApplicationTests {

	@Test
	void contextLoads() {
	}

}
